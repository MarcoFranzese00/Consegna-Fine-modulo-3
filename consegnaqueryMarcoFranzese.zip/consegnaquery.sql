CREATE DATABASE TOYS

USE TOYS;

/* Il blocco seguente � inerente la creazione delle tabelle */

CREATE TABLE Category (
CategoryID INT,
CategoryName varchar(100),
CONSTRAINT PK_Category PRIMARY KEY (CategoryID)
);

INSERT INTO Category (CategoryID, CategoryName) 
VALUES
(1, 'Giocattoli'),
(2, 'Giochi da tavolo');


CREATE TABLE Products (
ProductID INT,
ProductName varchar(100),
CategoryID INT,
UnitPrice DECIMAL(10,2),
CONSTRAINT PK_Products PRIMARY KEY (ProductID),
CONSTRAINT FK_Products_Category FOREIGN KEY (CategoryID) 
REFERENCES Category(CategoryID) 
);

INSERT INTO Products (ProductID, ProductName, CategoryID, UnitPrice) 
VALUES
(1, 'Pallone', 1, 49.99),
(2, 'Monopoly', 2, 39.99),
(3, 'Carotina Penna Parlante', 1, 19.99),
(4, 'Cluedo', 2, 349.99),
(5, 'Jenga', 1, 69.99);

SELECT *
FROM Products

CREATE TABLE RegionArea (
RegionAreaID INT,
RegionAreaName varchar(100),
CONSTRAINT PK_RegionArea PRIMARY KEY (RegionAreaID)
);

INSERT INTO RegionArea (RegionAreaID, RegionAreaName) VALUES
(1, 'North Europe'),
(2, 'East Europe'),
(3, 'South Europe'),
(4, 'West Europe'),
(5, 'Southeast Europe');



CREATE TABLE Region (
RegionID INT,
RegionName varchar(100),
RegionAreaID INT,
CONSTRAINT PK_Region PRIMARY KEY (RegionID),
CONSTRAINT FK_Region_RegionArea FOREIGN KEY (RegionAreaID)
REFERENCES RegionArea(RegionAreaID)
);

SELECT *
FROM Region

INSERT INTO Region (RegionID, RegionName, RegionAreaID)
VALUES
(1, 'Norway', 1),
(2, 'Slovenia', 2),
(3, 'Italy', 3),
(4, 'Belgium', 4),
(5, 'Greece', 5);

CREATE TABLE Sales (
OrderNumber INT,
ProductID INT,
RegionID INT,
OrderDate DATE,
OrderQuantity INT,
TotalPrice DECIMAL (10,2),
CONSTRAINT PK_Sales PRIMARY KEY (OrderNumber),
CONSTRAINT FK_Sales_Products FOREIGN KEY (ProductID)
REFERENCES Products(ProductID),
CONSTRAINT FK_Sales_Region FOREIGN KEY (RegionID)
REFERENCES Region(RegionID)
);

INSERT INTO Sales (OrderNumber, ProductID, RegionID, OrderDate, OrderQuantity, TotalPrice) 
VALUES
(1, 3, 3,'2020-07-22', 2, 39.98),
(2, 3, 2,'2019-10-14', 3, 59.97),
(3, 2, 3,'2022-05-18', 1, 39.99),
(4, 5, 1,'2018-09-25', 2, 139.98),
(5, 5, 2,'2017-04-30', 6, 419.94);




SELECT COUNT(*), CategoryID 
FROM Category
GROUP BY CategoryID 
HAVING COUNT(*) > 1

SELECT COUNT(*), ProductID 
FROM Products
GROUP BY ProductID
HAVING COUNT(*) > 1

SELECT COUNT(*), RegionAreaID
FROM RegionArea
GROUP BY RegionAreaID
HAVING COUNT(*) > 1

SELECT COUNT(*), RegionID
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1

SELECT COUNT(*), OrderNumber
FROM Sales
GROUP BY OrderNumber
HAVING COUNT(*) > 1




SELECT *
FROM Sales

SELECT 
s.OrderNumber,
s.OrderDate,
p.ProductName,
c.CategoryName,
r.RegionName AS State,
ra.RegionAreaName AS Area,
CASE 
	WHEN DATEDIFF(DAY,s.OrderDate,GETDATE()) <= 180 THEN 'FALSE'
	ELSE 'TRUE'
END				AS MoreThan180Days,
s.TotalPrice

FROM Sales AS s 

LEFT JOIN Products AS p
ON s.ProductID = p.ProductID
LEFT JOIN Category AS c
ON p.CategoryID = c.CategoryID
LEFT JOIN  Region AS r
ON s.RegionID = r.RegionID
LEFT JOIN RegionArea AS ra
ON  r.RegionAreaID = ra.RegionAreaID

/* 3o punto consegna */

SELECT 
p.ProductName,
YEAR(s.OrderDate)		AS Year,
SUM(s.TotalPrice)		AS AnnualTotalRevenue
FROM SALES AS s
LEFT JOIN Products AS p
ON s.ProductID = p.ProductID
GROUP BY p.ProductName, YEAR(s.OrderDate)

/* 4o punto consegna */

SELECT r.RegionName,
YEAR(s.OrderDate) AS Year,
SUM(s.TotalPrice) AS RevenuePerYear
FROM Sales AS s
LEFT JOIN Region AS r
ON s.RegionID = r.RegionID
GROUP BY r.RegionName, YEAR(s.OrderDate)
ORDER BY RevenuePerYear DESC

/* 5o punto consegna */

SELECT Category.CategoryName, 
COUNT(Category.CategoryName) AS MarketDemand
FROM Sales
LEFT JOIN Products
ON Sales.ProductID = Products.ProductID
LEFT JOIN Category
ON Category.CategoryID = Products.CategoryID
GROUP BY CategoryName
ORDER BY CategoryName

/* 6sto punto consegna */

/*Approccio 1*/

SELECT ProductName
FROM Products
WHERE ProductID NOT IN (SELECT ProductID
						FROM Sales)
				---------------------------
SELECT ProductName
FROM Products
WHERE ProductID IN (SELECT ProductID
						FROM Sales)

/*Approccio 2*/

SELECT Products.ProductName, OrderNumber
FROM Products
LEFT JOIN Sales
ON Products.ProductID = SALES.ProductID
WHERE Sales.ProductID IS NULL

/* 7mo punto consegna */

SELECT p.ProductName, MAX(s.OrderDate)
FROM Sales AS s
LEFT JOIN Products AS p
ON s.ProductID = p.ProductID
GROUP BY p.ProductName

SELECT *
FROM Sales

/* 8vo punto consegna */

CREATE VIEW VW_MF_PRODUCTS AS (

SELECT 
	p.ProductID,
	p.ProductName,
	c.CategoryName
FROM Products AS p
LEFT JOIN Category AS c
ON p.CategoryID = c.CategoryID
)

/* 9no punto consegna */

CREATE VIEW VW_MF_GEOGRAPHY AS (

SELECT	r.RegionName, 
		ra.RegionAreaName,
		r.RegionID
FROM Region AS r
LEFT JOIN RegionArea AS ra
ON r.RegionAreaID = ra.RegionAreaID
)

select *
from VW_MF_GEOGRAPHY

CREATE VIEW VW_MF_SALES AS (

SELECT *
FROM Sales)

)